#ifndef DEFS_HPP
#define DEFS_HPP

#define ALPHABET_SIZE 128
#define STATES 23
#define DEAD_STATE 0
#define INIT_STATE 1
#define ERROR_STATE 0

#endif