#ifndef DEFS_HPP
#define DEFS_HPP

#define ALPHABET_SIZE 128
#define STATES 10

#endif